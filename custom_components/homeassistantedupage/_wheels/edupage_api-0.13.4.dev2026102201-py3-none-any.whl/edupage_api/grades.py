import json
import logging
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional, Union

from edupage_api import grades
from edupage_api.dbi import DbiHelper
from edupage_api.exceptions import FailedToParseGradeDataError
from edupage_api.module import Module, ModuleHelper
from edupage_api.people import EduTeacher


_LOGGER = logging.getLogger(__name__)


@dataclass
class EduGrade:
    event_id: int | None
    title: str
    grade_n: int | float | str | None
    comment: str | None
    date: datetime
    subject_id: int
    subject_name: str | None
    teacher: EduTeacher | None
    max_points: float | None
    more_details: list[str] | None
    importance: float
    verbal: bool
    percent: float
    class_grade_avg: float | None
    grade_id: str | None = None

@dataclass
class EduTextGrade:
    grade_id: int
    comment: str | None
    grade_type: str
    date: datetime | None
    subject_id: int
    subject_name: str | None

class Term(Enum):
    FIRST = "P1"
    SECOND = "P2"


class Grades(Module):
    def __parse_grade_data(self, data: str) -> dict:
        json_string = data.split(".znamkyStudentViewer(")[1].split(
            ");\r\n\t\t});\r\n\t\t</script>"
        )[0]

        return json.loads(json_string)

    def __get_grade_data(self):
        request_url = f"https://{self.edupage.subdomain}.edupage.org/znamky/"
        response = self.edupage.session.get(request_url).content.decode()

        try:
            return self.__parse_grade_data(response)
        except (json.JSONDecodeError, IndexError):
            raise FailedToParseGradeDataError("Failed to parse JSON")

    def __get_grade_data_for_term(self, term: Term, year: int):
        request_url = f"https://{self.edupage.subdomain}.edupage.org/znamky/?what=studentviewer&znamky_yearid={year}&nadobdobie={term.value}"
        response = self.edupage.session.post(request_url).content.decode()

        try:
            return self.__parse_grade_data(response)
        except (json.JSONDecodeError, IndexError):
            raise FailedToParseGradeDataError("Failed to parse JSON")

    @ModuleHelper.logged_in
    def get_text_grades(self, term: Term | None, year: int | None) -> list[EduTextGrade]:
        grade_data = (
            self.__get_grade_data_for_term(term, year)
            if term and year
            else self.__get_grade_data()
        )
        
        text_grades = grade_data.get("vsetkyVcelicky")

        grades = []
        for grade in text_grades:
            grade_id = grade.get("VcelickaID")
            comment = grade.get("p_text")
            grade_type = grade.get("p_typ")

            date_str = grade.get("p_datum")
            date = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S") \
                if date_str is not None else None

            subject_id_str = grade.get("PredmetID")
            if subject_id_str is None or subject_id_str == "vsetky":
                continue

            subject_id = int(subject_id_str)
            subject_name = grade.get("predmet_meno")
            if subject_name is None:
                subject_name = DbiHelper(self.edupage).fetch_subject_name(subject_id)

            grades.append(
                EduTextGrade(
                    grade_id,
                    comment,
                    grade_type,
                    date,
                    subject_id,
                    subject_name
                )
            )

        return grades

    @ModuleHelper.logged_in
    def get_grades(self, term: Term | None, year: int | None) -> list[EduGrade]:
        grade_data = (
            self.__get_grade_data_for_term(term, year)
            if term and year
            else self.__get_grade_data()
        )

        if not isinstance(grade_data, dict):
            raise FailedToParseGradeDataError("Grade response must be an object")
        grades = grade_data.get("vsetkyZnamky")
        if not isinstance(grades, list):
            raise FailedToParseGradeDataError("Missing/invalid vsetkyZnamky list")
        _LOGGER.debug("Grade parser: received=%d term=%s year=%s", len(grades), term, year)
        report = {"received": len(grades), "parsed": 0, "skipped": 0, "skip_reasons": {}}

        def skip(row_index, row, reason):
            report["skipped"] += 1
            report["skip_reasons"][reason] = report["skip_reasons"].get(reason, 0) + 1
            _LOGGER.warning("Grade row skipped: row=%d reason=%s keys=%s",
                            row_index, reason, sorted(row))

        if not grades:
            self.edupage.grade_read_report = report
            return []
        events = grade_data.get("vsetkyUdalosti")
        if not isinstance(events, dict):
            raise FailedToParseGradeDataError("Missing/invalid vsetkyUdalosti object")
        grade_details = events.get("edupage")
        if not isinstance(grade_details, dict):
            raise FailedToParseGradeDataError("Missing/invalid vsetkyUdalosti.edupage object")

        output = []
        for row_index, grade in enumerate(grades):
            if not isinstance(grade, dict):
                raise FailedToParseGradeDataError("Invalid grade row (expected object)")
            # Standalone marks need not refer to a school event/paper.
            event_id_raw = grade.get("udalostid")
            event_id = int(event_id_raw) if event_id_raw not in (None, "", 0, "0") else None
            if event_id is None:
                _LOGGER.debug("Grade row without event: row=%d keys=%s", row_index, sorted(grade))
                details = grade
            else:
                details = grade_details.get(str(event_id))
                if not isinstance(details, dict):
                    raise FailedToParseGradeDataError(
                        f"Missing/invalid vsetkyUdalosti.edupage[{event_id}] "
                        "for an existing grade; refusing to omit it from averages"
                    )
            title = details.get("p_meno") or ""
            date_str = grade.get("datum")
            subject_id_str = details.get("PredmetID", details.get("predmetid"))
            if subject_id_str is None or subject_id_str == "vsetky":
                skip(row_index, grade, "missing_subject_id" if subject_id_str is None else "all_subjects")
                continue
            if not isinstance(date_str, str) or not isinstance(grade.get("data"), str):
                skip(row_index, grade, "missing_date_or_grade")
                continue
            try:
                date = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
            except ValueError:
                skip(row_index, grade, "invalid_date")
                continue

            subject_id = int(subject_id_str)
            subject_name = DbiHelper(self.edupage).fetch_subject_name(subject_id)

            # Teacher
            teacher_id_str = details.get("UcitelID", details.get("ucitelid"))
            if teacher_id_str is None:
                teacher = None
            else:
                teacher_id = int(teacher_id_str)
                teacher_data = DbiHelper(self.edupage).fetch_teacher_data(teacher_id)

                if teacher_data is None:
                    teacher = None
                else:
                    teacher = EduTeacher.parse(teacher_data, teacher_id, self.edupage)

            # Maximal points and importance
            grade_type = str(details.get("p_typ_udalosti"))
            max_points = None
            importance = 1.0 if event_id is None else None
            if grade_type == "1":
                # Normal grade (1 – 5)
                max_points = None
                importance = float(details.get("p_vaha", 20)) / 20
            elif grade_type == "2":
                # Points grade (in points – e.g. 0 – 20 points)
                max_points = float(details.get("p_vaha"))
                importance = None
            elif grade_type == "3":
                # Percental grade (0 – 100 %)
                max_points = float(details.get("p_vaha_body"))
                importance = float(details.get("p_vaha", 20)) / 20
            elif details.get("p_vaha") is not None:
                # Other grade types (e.g. "4" – symbolic grades like "Ú")
                # have no maximal points, only importance
                importance = float(details.get("p_vaha", 20)) / 20

            # More details coming from Edupage metadata
            more_details_raw = details.get("moredata")
            if isinstance(more_details_raw, list):
                more_details = [str(item) for item in more_details_raw]
            elif more_details_raw is None:
                more_details = None
            else:
                more_details = [str(more_details_raw)]
            # Grade
            grade_raw = grade.get("data").split(" (", 1)
            if grade_raw[0].isdigit():
                grade_n = float(grade_raw[0])
            else:
                grade_n = grade_raw[0]

            try:
                comment = grade_raw[1].rsplit(")", 1)[0]
            except IndexError:
                comment = None

            # Verbal and percents
            try:
                verbal = False

                if max_points:
                    percent = round(float(grade_n) / float(max_points) * 100, 2)
                elif max_points == 0:
                    percent = float("inf")
                else:
                    percent = None
            except:
                verbal = True
                percent = None

            class_grade_avg = None if details.get("priemer") is None else float(details.get("priemer"))

            grade = EduGrade(
                event_id,
                title,
                grade_n,
                comment,
                date,
                subject_id,
                subject_name,
                teacher,
                max_points,
                more_details,
                importance,
                verbal,
                percent,
                class_grade_avg,
                str(grade.get("znamkaid", grade.get("ZnamkaID")))
                if grade.get("znamkaid", grade.get("ZnamkaID")) is not None else None,
            )
            output.append(grade)
            report["parsed"] += 1

        _LOGGER.debug("Grade parser: received=%d parsed=%d skipped=%d",
                      len(grades), len(output), len(grades) - len(output))
        self.edupage.grade_read_report = report
        return output
